---
title: "关于"
date: 2018-12-29T20:24:28+08:00
hidden: true
draft: false
---

Hugo 官方主页: [https://gohugo.io/](https://gohugo.io/)

Hugo的安装方式有两种，一种是直接下载编译好的Hugo二进制文件。如果只是使用Hugo推荐用这种方式。另一种方式是获取Hugo的源码，自己编译。由于各种不可预料的网络问题，第二种方式不是那么轻易能成功，虽然最后我还是折腾出来了。

Hugo二进制下载地址: [https://github.com/gohugoio/hugo/releases](https://github.com/gohugoio/hugo/releases)

